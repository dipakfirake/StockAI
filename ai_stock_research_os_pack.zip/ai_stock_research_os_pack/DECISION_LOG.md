# Decision Log

## DEC-001
Decision: Build a research platform, not a broker.
Reason: The system should focus on alerts, paper trading, and analysis.

## DEC-002
Decision: Make it India-first.
Reason: Indian market hours, events, and behaviour must shape the product.

## DEC-003
Decision: Use checkpoints and resume files.
Reason: Work must continue smoothly across sessions and AI tools.
