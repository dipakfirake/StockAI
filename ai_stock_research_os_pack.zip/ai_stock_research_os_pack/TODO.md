# Todo

- Finalise MVP features
- Choose initial stack
- Define database entities
- Define first APIs
- Define first UI screens
- Define checkpoint update workflow
