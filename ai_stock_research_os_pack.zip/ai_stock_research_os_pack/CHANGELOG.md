# Changelog

## 2026-07-29
- Created the project operating system pack
- Defined the constitution
- Defined resume and checkpoint rules
- Drafted the master prompt
- Drafted Phase 1 roadmap
