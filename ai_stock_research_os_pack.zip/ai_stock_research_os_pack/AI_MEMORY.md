# AI Memory

## Persistent project memory
- India-first stock research platform
- Research only, no trade execution
- Explainable alerts and AI scores
- Paper trading and backtesting required
- Checkpoint-based continuation required

## Decision history
- Use phased development
- Store progress in checkpoint files
- Keep architecture modular
- Prioritise data quality before advanced AI
