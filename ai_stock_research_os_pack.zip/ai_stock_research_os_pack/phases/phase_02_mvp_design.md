# Phase 2 — MVP Design

## Goal
Choose the smallest useful feature set that can be built quickly and validated.

## Suggested MVP
- Stock search
- basic chart
- key indicators
- watchlist
- alerts
- simple paper trading
- simple backtesting
- checkpoint system

## Exit criteria
- MVP scope approved
- First build order defined
