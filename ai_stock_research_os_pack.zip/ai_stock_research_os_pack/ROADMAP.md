# Roadmap

## Phase 1 — Product definition
Define the problem, users, goals, and boundaries.

## Phase 2 — MVP design
Choose the smallest useful feature set.

## Phase 3 — System architecture
Design frontend, backend, data, AI, APIs, and storage.

## Phase 4 — Market data layer
Build live/historical data ingestion and validation.

## Phase 5 — Charts and indicators
Build charting, overlays, technical studies, and pattern detection.

## Phase 6 — Alerts and scanners
Add rule-based scanners and intelligent alerts.

## Phase 7 — Paper trading
Add virtual trading, fills, PnL, risk, and history.

## Phase 8 — Backtesting
Add strategy testing, realism, and metrics.

## Phase 9 — AI engine
Add scoring, explainability, calibration, and prediction archive.

## Phase 10 — India intelligence
Add RBI, sector, breadth, corporate actions, and regime logic.

## Phase 11 — Advanced features
Add optimiser, journal, scenario tools, and community features.

## Phase 12 — Scaling and production
Add monitoring, resilience, performance, and open-source readiness.
